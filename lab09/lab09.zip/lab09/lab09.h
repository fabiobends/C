#include <18F4550.h>
#device ADC=10
#use delay(crystal=20000000)

